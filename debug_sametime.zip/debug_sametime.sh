#/bin/bash
echo "*******************************************"
echo "welcome to CYONE  HCL Sametime debug utility"
echo "  v.1.1      vlaad@cyone.eu"
echo "*******************************************"
host=$(uname -n)

now=$(date +"%Y_%m_%d_%H_%M")
debug_filename="sametime_logs_"${now}
#change value if you wish
HCLDir="HCL_TECHNICAL_SUPPORT"
curdir=$(pwd)

ff=$debug_filename

debug_filename=${HCLDir}/$debug_filename
mkdir -p ${HCLDir}
mkdir -p ${HCLDir}/BACKUP

echo "1/7. Debug filename:" ${debug_filename}.txt
echo "2/7. Running docker-compose logs"

docker-compose logs > ${debug_filename}.txt


echo "3/7. Gathering Netstat output, adding to debug information"
netstat -na > ${HCLDir}/netstat_${now}.txt

echo "4/7. Generating MD5 hashes of files, so support can verify. This may take 20-30 sec"
find -type f -exec md5sum '{}' \; > ${HCLDir}/md5sum.txt


echo "4/7. Gathering server network config."
ifconfig  > ${HCLDir}/network.txt
echo " ===========     Resolv.conf file ===================   " > ${HCLDir}/network.txt
cat /etc/resolv.conf >> ${HCLDir}/network.txt
echo " ============ end of resolv.conf ====================== " >> ${HCLDir}/network.txt
echo " === now /etc/hosts file ============================== " >> ${HCLDir}/network.txt
cat /etc/hosts >> ${HCLDir}/network.txt
echo " ============= end of hosts file ===================" >> ${HCLDir}/network.txt



echo "5/7. Zipping files, please wait 1 sec"




zip ${debug_filename}.zip ${debug_filename}.txt custom.env .env docker-compose.yml ${HCLDir}/netstat_${now}.txt ${HCLDir}/md5sum.txt ${HCLDir}/network.txt

echo "Lets backup important files. Dont forget to backup them outside this server!"
echo "6/7. Backuping .env docker-compose.yml custom.env to ${HCLDir} with timestamp ${now}"

cp .env ${HCLDir}/BACKUP/.env_${now}
cp docker-compose.yml ${HCLDir}/BACKUP/docker_compose_${now}
cp custom.env ${HCLDir}/BACKUP/custom.env_${now}


#ls -lh ${debug_filename}.*
echo "7/7. Information: Size of debug directory: " ${HCLDir}
du -h ${HCLDir}
#grep -i "error" ${debug_filename} | sort | uniq -c  | sort -r

#ls -la ${HCLDir}
echo "*********"
echo "File ${curdir}/${debug_filename}.zip has all information to debug issue."
echo "Powered by CYONE.EU. Check out www for great products for Notes/Domino/Traveler/Sametime"
echo "use following command to download ZIP to your local PC" 
echo "           scp root@${host}:${curdir}/${debug_filename}.zip ${ff}.zip"
